// GOALS for this week
// Clean up the TODOs
// Configuration

#include <pebble.h>
enum {
  KEY_TEMPERATURE = 0,
  KEY_CONDITIONS,
  KEY_ID,
  KEY_NAME,
  KEY_SUNRISE,
  KEY_SUNSET
};

// TODO: Should 'bounds' be global? no need but as a style thing since it shows up in a #define
#define BATTERY_FRAME   (GRect(0, 0, bounds.size.w, is_graphic_meter_else(10,15)))
#define TIME_FRAME      (GRect(0, bounds.size.h * .4, bounds.size.w, 50))
#define BT_FRAME        (GRect(PBL_IF_ROUND_ELSE(15, 0), bounds.size.h *.4 + 19, 15, 15))
//#define BT_FRAME        (GRect(PBL_IF_ROUND_ELSE(15, 0), is_graphic_meter_else(38, 43), 15, 15))
#define DATE_FRAME      (GRect(0, bounds.size.h * .4 - 23, bounds.size.w, 35))
#define DAY_FRAME       (GRect(0, bounds.size.h * .4 + 38, bounds.size.w, 36))
#define STEPS_FRAME     (GRect(0, bounds.size.h - 25, bounds.size.w, 25))
#define BIG_TEMP_FRAME  (GRect(0, is_graphic_meter_else(10,15), bounds.size.w, 27))
#define TEMP_FRAME      (GRect(0, is_graphic_meter_else(10,15), bounds.size.w/2, 27))
#define COND_FRAME      (GRect(bounds.size.w/2, is_graphic_meter_else(10,15), bounds.size.w/2, 27))
#define LOCATION_FRAME  (GRect(0, is_graphic_meter_else(35, 38), bounds.size.w, 16))

const uint8_t  MAX_DOTS = 5;
// Buffer the day / night time switch around sunrise & sunset
const int CIVIL_TWILIGHT_BUFFER = 900; // 15 minutes

const int W_ICON_BIG_WIND = 'F';
const int W_ICON_MIST = 'M';
const int W_ICON_CLEAR_DAY = 'B'; //'1';
const int W_ICON_CLEAR_NIGHT = 'C'; //'2';
const int W_ICON_PARTLY_CLOUDY_DAY = 'H'; //3';
const int W_ICON_PARTLY_CLOUDY_NIGHT = 'I'; //'4';
const int W_ICON_CLOUDY = 'Y'; //5';
const int W_ICON_THUNDERSTORM = 'P'; //'6';
const int W_ICON_LIGHT_RAIN = 'Q'; //'7';
const int W_ICON_RAIN = 'R'; //'8';
const int W_ICON_WINDY = 'S'; //9';
const int W_ICON_LIGHT_SNOW = 'V'; //'\'';
const int W_ICON_SNOW = 'W'; //'#';
const int W_ICON_HAIL = 'X'; //'$';
const int W_ICON_THERMOMETER = 27; // '
const int W_ICON_NA = ')';

static Window *s_main_window;
static Layer *s_gBattery_layer;
static TextLayer *s_time_layer;
static TextLayer *s_date_layer;
static TextLayer *s_day_layer;
static TextLayer *s_steps_layer;
static TextLayer *s_weather_layer;
static TextLayer *s_conditions_layer;
static TextLayer *s_battery_layer;
static TextLayer *s_whereami_layer;
static BitmapLayer  *s_bt_icon_layer;
static GBitmap      *s_bt_on_icon_bitmap, *s_bt_off_icon_bitmap; 

static int s_battery_level;
static GFont s_conditions_font;
static GFont s_steps_font;
static int8_t dots = 5; 

//TODO: One day we're going to make a configuration page to set these 
const bool is_graphic_conditions = true;
const bool is_graphic_meter = true;
const bool is_celsius = false;
const bool show_location = true;
const int step_goal = 10000;

static void bluetooth_callback(bool is_connected){
  if(!is_connected) {
    // Issue a vibrating alert
    vibes_double_pulse();
    bitmap_layer_set_bitmap(s_bt_icon_layer, s_bt_off_icon_bitmap);
  }else{
     bitmap_layer_set_bitmap(s_bt_icon_layer, s_bt_on_icon_bitmap);
  }
  
}

static bool is_night_time(int sunrise, int sunset, int utc) 
{
  return utc < (sunrise - CIVIL_TWILIGHT_BUFFER) || 
         utc > (sunset  + CIVIL_TWILIGHT_BUFFER);
}

// Convert weather condition ID from openweathermap to font icon
// Refer to: http://bugs.openweathermap.org/projects/api/wiki/Weather_Condition_Codes
int open_weather_icon_for_condition(int c, bool night_time){
  if (c < 100) {
    return W_ICON_NA;
  }
  // Thunderstorm 
  else if (c < 300) {
    return W_ICON_THUNDERSTORM;
  }
  // Drizzle
  else if (c < 500) {
    return W_ICON_LIGHT_RAIN;
  }
  // Rain / Freezing rain / Shower rain
  else if (c < 600) {
    return W_ICON_RAIN;
  }
  // Light Snow
  else if (c == 600 || c == 615 || c == 620){
    return W_ICON_LIGHT_SNOW;
  }
  // Sleet
  else if (c == 611 || c == 612) {
    return W_ICON_HAIL; 
  }
  // Snow
  else if (c < 700) {
    return W_ICON_SNOW;
  }
  // Fog / Mist / Haze / etc.
  else if (c < 771) {
    return W_ICON_MIST;
  }
  // Tornado / Squalls
  else if (c < 800) {
    return W_ICON_WINDY;
  }
  // Sky is clear or Few Clouds
  else if (c == 800 || c == 801) {
    if (night_time)
      return W_ICON_CLEAR_NIGHT;
    else
      return W_ICON_CLEAR_DAY;
  }
  // scattered clouds or broken clouds
  else if (c == 802 || c == 803) {
    if (night_time)
      return W_ICON_PARTLY_CLOUDY_NIGHT;
    else
      return W_ICON_PARTLY_CLOUDY_DAY;
  }
  // overcast clouds
  else if (c == 804) {
    return W_ICON_CLOUDY;
  }
  // Hail
  else if (c == 906) {
    return W_ICON_HAIL;
  }
  // Extreme - Windy/Tornado/Hurricane
  else if ((c >= 900 && c <= 902) || c == 905 || (c >= 957 && c <= 962)) {
    return W_ICON_BIG_WIND;
  }
  // Cold
  else if (c == 903) {
      return W_ICON_THERMOMETER;
  }
  // Hot
  else if (c == 904) {
      return W_ICON_THERMOMETER;
  }
  // Gentle to strong breeze
  else if (c >= 950 && c <= 956) {
    return W_ICON_WINDY;
  }
  else {
    // Weather condition not available
    return W_ICON_NA;
  }
}

int is_graphic_meter_else(int if_true, int if_false){
  if (is_graphic_meter) return(if_true); else return(if_false);
}

//set background to green if goal acheived
void check_step_goal(int s_steps){
  if (s_steps >= step_goal)
    text_layer_set_background_color(s_steps_layer, GColorMidnightGreen);
  else
    text_layer_set_background_color(s_steps_layer, GColorFolly);
}

static void health_handler(HealthEventType event, void *context) {
  static char s_value_buffer[10];
  int s_current_steps;
  
  s_current_steps = (int)health_service_sum_today(HealthMetricStepCount);
  check_step_goal(s_current_steps);
  snprintf(s_value_buffer, sizeof(s_value_buffer), "%d", s_current_steps);
  text_layer_set_text(s_steps_layer, s_value_buffer);
}

// Update graphic battery meter
void battery_layer_update(Layer *me, GContext *ctx) 
{
  int8_t spacer  =  PBL_IF_ROUND_ELSE(7, 9); // pixels - less for a round watch
  int offset = spacer * (MAX_DOTS+1); // TODO: this is prolly just a coinkydinky
                                      // should get actual width divide it by 2 subtract spacer and all that jazz
                                      // this would be a case where a global 'bounds' would be useful
  int dot_size =  PBL_IF_ROUND_ELSE(2, 3); // smallerer for a round watch
  offset =  PBL_IF_ROUND_ELSE(75, offset); // ditto
  
  graphics_context_set_fill_color(ctx, GColorDukeBlue);
  graphics_context_set_stroke_color(ctx, GColorDukeBlue);
  graphics_fill_rect(ctx, GRect(0, 0, 244,40), 0, GCornerNone);
  
  if (dots==0){
    graphics_context_set_fill_color(ctx, GColorRed);
    graphics_context_set_stroke_color(ctx, GColorRed);
  }else{
    graphics_context_set_fill_color(ctx, GColorYellow);
    graphics_context_set_stroke_color(ctx, GColorYellow);
  }
  
  for (int i=0; i<MAX_DOTS; i++) {
    if (i<dots) {
      graphics_fill_circle(ctx, GPoint(offset+(i*spacer), 4), dot_size);
    } else {
      graphics_draw_circle(ctx, GPoint(offset+(i*spacer), 4), dot_size);
    }
  } 
}

// Update text battery meter
static void battery_update_proc(TextLayer *layer) {
  static char battery_buffer[4];
  
  // write out battery level text 
  snprintf(battery_buffer, sizeof(battery_buffer), "%d%%X", (int)s_battery_level);
  text_layer_set_text(layer, battery_buffer);
}

static void battery_callback(BatteryChargeState state) {
  // Record the new battery level
  s_battery_level = state.charge_percent;
  
  // Update meter
  if (is_graphic_meter){
    if (s_battery_level >= 80) {
        dots = MAX_DOTS;
      } else if (s_battery_level >= 60 && s_battery_level < 80) {
        dots = 4;
      } else if (s_battery_level >= 40 && s_battery_level < 60) {
        dots = 3;
      } else if (s_battery_level >= 20 && s_battery_level < 40) {
        dots = 2;
      } else if (s_battery_level == 0) {
        dots = 0;
      }else {
        dots = 1;
      }
      layer_mark_dirty(s_gBattery_layer);
    }
  battery_update_proc(s_battery_layer);
}

// Create the layer for the graphic battery meter!
void battery_layer_create(GRect frame, Window *window)
{
  s_gBattery_layer = layer_create(frame);
  layer_set_update_proc(s_gBattery_layer, battery_layer_update);
  layer_add_child(window_get_root_layer(window), s_gBattery_layer);
}

//configure and display text layer
void configure_layer (TextLayer *layer, Layer *window, GColor bg_color, 
                      GColor text_color, GFont font, GTextAlignment alignment, char *txt){
  text_layer_set_background_color(layer, bg_color);
  text_layer_set_text_color(layer, text_color);
  text_layer_set_text(layer, txt);
  text_layer_set_font(layer, font);
  text_layer_set_text_alignment(layer, alignment);
  layer_add_child(window, text_layer_get_layer(layer));
}

static void update_time() {
  static char s_time_buffer[8];
  static char s_date_buffer[16];
  static char s_day_buffer[10];
  
  // Get a tm structure
  time_t temp = time(NULL); 
  struct tm *tick_time = localtime(&temp);

  // Write the current hours and minutes into a buffer
  strftime(s_time_buffer, sizeof(s_time_buffer), clock_is_24h_style() ?
                                          "%H:%M" : "%I:%M", tick_time);
  // Display this time on the TextLayer
  text_layer_set_text(s_time_layer, s_time_buffer);
  
  // Write the day into the buffer
  strftime(s_day_buffer, sizeof(s_day_buffer), "%A", tick_time);
  text_layer_set_text(s_day_layer, s_day_buffer);
  
  // Write the date into the buffer
  strftime(s_date_buffer, sizeof(s_date_buffer), "%B %d", tick_time);
  text_layer_set_text(s_date_layer, s_date_buffer);  
}

// Read & display the weather data returned from the JS call
static void inbox_received_callback(DictionaryIterator *iterator, void *context) {
  // Store incoming information
  static char temperature_buffer[8];
  static char conditions_buffer[32];
  static char whereami_buffer[32];
  
  // Read tuples for data
  Tuple *temp_tuple = dict_find(iterator, KEY_TEMPERATURE);
  Tuple *conditions_tuple = dict_find(iterator, KEY_CONDITIONS);
  Tuple *id_tuple = dict_find(iterator, KEY_ID);
  Tuple *name_tuple = dict_find(iterator, KEY_NAME);
  Tuple *sunrise_tuple = dict_find(iterator, KEY_SUNRISE); 
  Tuple *sunset_tuple = dict_find(iterator, KEY_SUNSET);
  
  //current time for day/night
  time_t current_time = time(NULL);
  bool night_time = is_night_time((int)sunrise_tuple->value->int32, (int)sunset_tuple->value->int32, current_time);
  
  if (show_location){
    // put location on whereami layer
    snprintf(whereami_buffer, sizeof(whereami_buffer), "%s", name_tuple->value->cstring);
    text_layer_set_text(s_whereami_layer, whereami_buffer);
  }
  
  // If all data is available, use it
  if(temp_tuple && conditions_tuple) {
    if (is_celsius){
      snprintf(temperature_buffer, sizeof(temperature_buffer), "%dC", (int)temp_tuple->value->int32);
    }else{
      snprintf(temperature_buffer, sizeof(temperature_buffer), "%dF", (int)(temp_tuple->value->int32 * 1.8) + 32);
    }
    
    if (is_graphic_conditions){
      text_layer_set_text(s_weather_layer, strcat(temperature_buffer," "));
      snprintf(conditions_buffer, sizeof(conditions_buffer), "%c",
        open_weather_icon_for_condition((int)id_tuple->value->int32, night_time));
      text_layer_set_text(s_conditions_layer, conditions_buffer);    
      //text_layer_set_text(s_conditions_layer, 
      //  open_weather_icon_for_condition((int)id_tuple->value->int32, night_time));
    }else{
      snprintf(conditions_buffer, sizeof(conditions_buffer), "-%s", conditions_tuple->value->cstring);
      text_layer_set_text(s_weather_layer, strcat(temperature_buffer, conditions_buffer));
    }  
  }
}
static void inbox_dropped_callback(AppMessageResult reason, void *context) {
  APP_LOG(APP_LOG_LEVEL_ERROR, "Message dropped!");
}
static void outbox_failed_callback(DictionaryIterator *iterator, AppMessageResult reason, void *context) {
  APP_LOG(APP_LOG_LEVEL_ERROR, "Outbox send failed!");
}
static void outbox_sent_callback(DictionaryIterator *iterator, void *context) {
  APP_LOG(APP_LOG_LEVEL_INFO, "Outbox send success!");
}

static void tick_handler(struct tm *tick_time, TimeUnits units_changed) {
  update_time();
  // Get weather update every 30 minutes
  if(tick_time->tm_min % 30 == 0) {
    // Begin dictionary
    DictionaryIterator *iter;
    app_message_outbox_begin(&iter);

    // Add a key-value pair
    dict_write_uint8(iter, 0, 0);

    //  Send the message!
    app_message_outbox_send();
  }
}

static GFont day_font(){
  // If it's Wednesday use a smaller font!
  // and why don't we use this font for everyday?
  time_t temp = time(NULL);
  struct tm *tick_time = localtime(&temp);
  
  if (tick_time->tm_wday == 3)
    return  fonts_load_custom_font(
      resource_get_handle(RESOURCE_ID_FONT_FRNKLN_GOTHIC_BOLD_22));
  else
    return fonts_get_system_font(FONT_KEY_BITHAM_30_BLACK);
  //
}


static void main_window_load(Window *window) {
  GTextAlignment temp_alignment;
  
  // Get information about the Window
  Layer *window_layer = window_get_root_layer(window);
  
  //window_set_background_color(window, GColorWhite);
  GRect bounds = layer_get_bounds(window_layer);
  
  // Create the Bluetooth icon GBitmap
  s_bt_on_icon_bitmap = gbitmap_create_with_resource(RESOURCE_ID_IMAGE_BT_ON);
  s_bt_off_icon_bitmap = gbitmap_create_with_resource(RESOURCE_ID_IMAGE_BT_OFF);
  // Create the BitmapLayer to display the GBitmap
  s_bt_icon_layer = bitmap_layer_create(BT_FRAME);
  bitmap_layer_set_bitmap(s_bt_icon_layer, s_bt_off_icon_bitmap);
  layer_add_child(window_get_root_layer(window), bitmap_layer_get_layer(s_bt_icon_layer));
  
  // Create the layers
  s_time_layer = text_layer_create(TIME_FRAME);
  configure_layer (s_time_layer, window_layer, GColorClear, GColorOxfordBlue, 
    fonts_get_system_font(FONT_KEY_BITHAM_42_LIGHT), GTextAlignmentCenter, "00:00");
  
  s_date_layer = text_layer_create(DATE_FRAME);
  configure_layer (s_date_layer, window_layer, GColorClear, GColorDarkGreen, 
    fonts_get_system_font(FONT_KEY_GOTHIC_28_BOLD), GTextAlignmentCenter, "Today");
  
  s_day_layer = text_layer_create(DAY_FRAME);
  configure_layer (s_day_layer, window_layer, GColorClear, GColorOrange, 
    day_font(), GTextAlignmentCenter, "Today");
  s_steps_layer = text_layer_create(STEPS_FRAME);
  s_steps_font = fonts_load_custom_font(
    resource_get_handle(RESOURCE_ID_FONT_FRNKLN_GOTHIC_BOLD_20));
  configure_layer(s_steps_layer, window_layer, GColorFolly, GColorElectricBlue, 
    s_steps_font, GTextAlignmentCenter, "--");
  
  if (is_graphic_conditions){
    temp_alignment = GTextAlignmentRight;
    s_weather_layer = text_layer_create(TEMP_FRAME);
    
  }else{
    temp_alignment = GTextAlignmentCenter;
    s_weather_layer = text_layer_create(BIG_TEMP_FRAME);
  }
  configure_layer(s_weather_layer, window_layer, GColorDukeBlue, GColorChromeYellow,  
    fonts_get_system_font(FONT_KEY_GOTHIC_18_BOLD), temp_alignment, "Loading...");

   // add & configure the conditions layer
  s_conditions_layer = text_layer_create(COND_FRAME);
  if (is_graphic_conditions){  //TODO: this should be combined with the if(is_graphic_condition) abo
    s_conditions_font = fonts_load_custom_font(
      resource_get_handle(RESOURCE_ID_FONT_METEOCONS_24));
    configure_layer(s_conditions_layer, window_layer, GColorDukeBlue, GColorChromeYellow,
    s_conditions_font, GTextAlignmentLeft, "");
  }
  
  
  
  s_battery_layer = text_layer_create(BATTERY_FRAME);
  // Style the battery layer
  if (is_graphic_meter){
    battery_layer_create(BATTERY_FRAME, window);
  }else{
    // Create battery meter layer
    configure_layer(s_battery_layer, window_layer, GColorDukeBlue, GColorYellow,
      fonts_get_system_font(FONT_KEY_GOTHIC_14_BOLD), GTextAlignmentCenter, "--");
  }
  
  s_whereami_layer = text_layer_create(LOCATION_FRAME);
  if (show_location){
    // style the location layer
    configure_layer(s_whereami_layer, window_layer, GColorClear, GColorBlack,
      fonts_get_system_font(FONT_KEY_GOTHIC_14), GTextAlignmentCenter, "Where am I?");
  }
  
  // Show the correct state of the BT connection from the start
  bluetooth_callback(connection_service_peek_pebble_app_connection());
}

static void main_window_unload(Window *window) {
  // Destroy time TextLayer
  text_layer_destroy(s_time_layer);
  
  // Destroy date TextLayer
  text_layer_destroy(s_date_layer);
  text_layer_destroy(s_day_layer);
  text_layer_destroy(s_steps_layer);
  text_layer_destroy(s_weather_layer);
  text_layer_destroy(s_conditions_layer);
  text_layer_destroy(s_whereami_layer);
  layer_destroy(s_gBattery_layer);
  text_layer_destroy(s_battery_layer);
  
  //Destroy the custom fonts
  fonts_unload_custom_font(s_steps_font);
  fonts_unload_custom_font(s_conditions_font);
  
  gbitmap_destroy(s_bt_on_icon_bitmap);
  gbitmap_destroy(s_bt_off_icon_bitmap);
  bitmap_layer_destroy(s_bt_icon_layer);
  
}


static void init() {
  // Create main Window element and assign to pointer
  s_main_window = window_create();

  // Register callbacks
  app_message_register_inbox_received(inbox_received_callback);
  app_message_register_inbox_dropped(inbox_dropped_callback);
  app_message_register_outbox_failed(outbox_failed_callback);
  app_message_register_outbox_sent(outbox_sent_callback);
  battery_state_service_subscribe(battery_callback);
  
  // open AppMessage
  const int inbox_size = 128;
  const int outbox_size = 128;
  app_message_open(inbox_size, outbox_size);
  
  // Set handlers to manage the elements inside the Window
  window_set_window_handlers(s_main_window, (WindowHandlers) {
    .load = main_window_load,
    .unload = main_window_unload
  });

  // Show the Window on the watch, with animated=true
  window_stack_push(s_main_window, true);

  // Make sure the time is displayed from the start
  update_time();
  
  // Make sure battery level is displayed from the start
  battery_callback(battery_state_service_peek());

  // Register with TickTimerService
  tick_timer_service_subscribe(MINUTE_UNIT, tick_handler);
  
  // Subscribe to health service events to get steps
  health_service_events_subscribe(health_handler, NULL);
  
  // Register for bluetooh connection update
  connection_service_subscribe((ConnectionHandlers){
    .pebble_app_connection_handler = bluetooth_callback
  });
}

static void deinit() {
  // Destroy Window
  window_destroy(s_main_window);
}

int main(void) {
  init();
  app_event_loop();
  deinit();
}